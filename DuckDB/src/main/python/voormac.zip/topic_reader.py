import re
import subprocess


class TopicReader:

    def __init__(self, topics_file_name):
        self.filename = topics_file_name
        self.file = open(self.filename)
        self.topics = []
        print("Read topics...", flush=True)
        self._read_topics_file()
        print("Preprocess topics...", flush=True)
        self.replace_by_preprocessed_title("D:\Daan\IR\olddog\src\main\python\preprocessed_titles.txt")
        #self.write_titles_to_file("D:\Daan\IR\olddog\src\main\python\\titles.txt")
        #self._preprocess_titles()

    def _read_topics_file(self):
        while True:
            line = self.file.readline()
            if not line:
                break

            if not line.strip():
                continue

            while line and not line.startswith('<top>'):
                line = self.file.readline()
            if not line:
                break

            while not line.startswith('<num>'):
                line = self.file.readline()
            topic_no = int(re.search('Number: (\d+)', line.strip()).group(1))

            # print("Parsing topic {}".format(topic_no),flush=True)

            while not line.startswith('<title>'):
                line = self.file.readline()

            # Robust04 specific:
            topic_title = line.strip()[8:]

            line = self.file.readline().strip()
            while not line.startswith('</title>') and not line.startswith('<desc>'):
                topic_title += line
                line = self.file.readline().strip()

            while not line.startswith('<desc>'):
                line = self.file.readline().strip()

            topic_desc = ""
            line = self.file.readline().strip()
            while not line.startswith('</desc>') and not line.startswith('<narr>'):
                topic_desc += line
                line = self.file.readline().strip()

            while not line.startswith('<narr>'):
                line = self.file.readline().strip()

            topic_nar = ""
            line = self.file.readline().strip()

            while not line.startswith('</narr>') and not line.startswith('</top>'):
                topic_nar += line
                line = self.file.readline().strip()

            while not line.startswith('</top>'):
                line = self.file.readline().strip()

            topic = {
                'number': topic_no,
                'title': topic_title,
                'description': topic_desc,
                'narrative': topic_nar
            }
            self.topics.append(topic)

    def _preprocess_titles(self):
        for i, topic in enumerate(self.topics):
            title = topic['title']
            print("{}".format(title).split())
            process = subprocess.Popen(
                """D:\Daan\IR\olddog\\target\\appassembler\\bin\\nl.ru.preprocess.ProcessQuery {}""".format(title).split(),
                stdout=subprocess.PIPE)
            stdout = process.communicate()[0].decode("utf-8").strip()
            self.topics[i]['title'] = stdout

    def replace_by_preprocessed_title(self, filename):
        ifile = open(filename, "r")
        for i, topic in enumerate(self.topics):
            line = ifile.readline().strip()
            self.topics[i]['title'] = line


    # Write titles to text file to be processed by olddog
    def write_titles_to_file(self, filename):
        ofile = open(filename, 'w+')
        for i, topic in enumerate(self.topics):
            title = topic['title']
            ofile.write("{}\n".format(title))

        ofile.close()


    def get_topics(self):
        return self.topics